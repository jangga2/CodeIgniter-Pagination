# ci-app-pagination
Membuat pagination pada ci-app
